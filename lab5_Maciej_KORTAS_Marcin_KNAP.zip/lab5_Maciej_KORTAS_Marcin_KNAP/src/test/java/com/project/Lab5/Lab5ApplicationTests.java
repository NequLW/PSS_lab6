package com.project.Laboratorium1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Laboratorium1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
