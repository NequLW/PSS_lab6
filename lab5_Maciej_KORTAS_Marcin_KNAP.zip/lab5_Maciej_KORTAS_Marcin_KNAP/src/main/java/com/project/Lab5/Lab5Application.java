package com.project.Laboratorium1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.project.Lab5.configuration.SpringFoxConfig;

@SpringBootApplication
public class Laboratorium1Application {

	public static void main(String[] args) {
		SpringApplication.run(Laboratorium1Application.class, args);
	}

}
